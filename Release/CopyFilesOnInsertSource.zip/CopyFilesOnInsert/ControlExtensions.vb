﻿'http://www.codeproject.com/Articles/37642/Avoiding-InvokeRequired
Module ControlExtensions
    <System.Runtime.CompilerServices.Extension()> _
    Public Sub UIThread(control As Control, code As Action)
        If control.InvokeRequired Then
            control.BeginInvoke(code)
            Return
        End If
        code.Invoke()
    End Sub

    <System.Runtime.CompilerServices.Extension()> _
    Public Sub UIThreadInvoke(control As Control, code As Action)
        If control.InvokeRequired Then
            control.Invoke(code)
            Return
        End If
        code.Invoke()
    End Sub
End Module
